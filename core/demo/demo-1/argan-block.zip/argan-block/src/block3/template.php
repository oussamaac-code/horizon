
<?php 

$postID= get_queried_object_id();
$category= get_the_category();

$args = array(

    'post_type'      => 'post',
    'post_status'    => 'publish',
    'numberposts'    =>  3,
    'category'       => $category[0]->term_id,
    'exclude'        => array($postID)
);

$posts= get_posts($args);

$str = '<div class="wp-block-create-block-related-post-block">';
                        
    foreach($posts as $post){

        $str .= sprintf(
            '<div class="related-post"><div class="img"> %1$s </div><h6><a href=" %2$s "> %3$s </a></h6></div>',
            get_the_post_thumbnail($post->ID),
            get_permalink($post->ID),
            $post->post_title

        );
    }

$str .= '</div>';?>


