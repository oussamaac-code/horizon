<?php
/**
 * Plugin Name:       Argan Block
 * Description:       Example block scaffolded with Create Block tool.
 * Requires at least: 6.1
 * Requires PHP:      7.0
 * Version:           0.1.0
 * Author:            The WordPress Contributors
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       argan-block
 *
 * @package           create-block
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Registers the block using the metadata loaded from the `block.json` file.
 * Behind the scenes, it registers also all assets so they can be enqueued
 * through the block editor in the corresponding context.
 *
 * @see https://developer.wordpress.org/reference/functions/register_block_type/
 */
function argan_block_argan_block_block_init() {

	register_block_type( __DIR__ . '/build/block1', [
		'render_callback' => 'gutenberg_examples_author_callback'
	] );

	register_block_type( __DIR__ . '/build/block2' );


	register_block_type( __DIR__ . '/build/block3', [
		'render_callback' => 'gutenberg_related_posts_block_callback'
	] );

		
}
add_action( 'init', 'argan_block_argan_block_block_init' );



// render callback

function gutenberg_examples_author_callback(){
	
    $post_id = get_queried_object_id();
	$author_id = get_post_field( 'post_author', $post_id );

	
	return sprintf(

		'<div class="wp-block-create-block-author-block"><div class="img"> %1$s </div> <div class="info"><h5> %2$s %3$s </h5><p> %4$s </p></div></div>',
		get_avatar($author_id, 100),
		get_the_author_meta('first_name', $author_id ),
		get_the_author_meta('last_name', $author_id ),
		get_the_author_meta('description', $author_id  ),
		
	);

}


function gutenberg_related_posts_block_callback(){


	$postID= get_queried_object_id();
	$category= get_the_category();

	$args = array(

		'post_type'      => 'post',
		'post_status'    => 'publish',
		'numberposts'    =>  3,
		'category'       => $category[0]->term_id,
		'exclude'        => array($postID)
	);

	$posts= get_posts($args);

	$str = '<div class="wp-block-create-block-related-post-block"><h5 class="wp-block-heading">Related posts</h5>';
		
		foreach($posts as $post){

			$str .= sprintf(
				'<div class="related-post"><div class="img"> %1$s </div><h6><a href=" %2$s "> %3$s </a></h6></div>',
				get_the_post_thumbnail($post->ID),
				get_permalink($post->ID),
				$post->post_title

			);
		}

	$str .= '</div>';

	
	return $str;

}

